<?php
$js = array(
		'coupon.js'
	);
?>
